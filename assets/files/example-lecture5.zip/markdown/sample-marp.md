---
marp: true
title: Title As It Is In the Proceedings
author: Author
---

# Motivation
## The Basic Problem That We Studied

--- 

### Make Titles Informative. Use Uppercase Letters.

- Use ``itemize`` a lot.
- Use very short sentences or short phrases.
---

### Make Titles Informative.

You can create overlays

- using the ``pause`` command:
    - First item
    - Second item
- using overlay specifications:
    - First item
    - Second item
- using the general ``uncover'' command:
    - First item
    - Second item

---

## Previous Work

---
### This is a test slide for mathematics

J. Leray ('34) first proved the global existence of weak solution in $L^\infty_tL^2_x \cap L^2_t \dot{H}^1_x$ of the Navier-Stokes equation:
$$
\partial_t u -\Delta u +\nabla p +(u\cdot\nabla)u=0,\quad \nabla \cdot u=0\quad \text{in } \mathbb{R}^3\times (0,\infty).
$$
Uniqueness in 2D was established by Ladyzhenskaya('58). However, the uniqueness question in 3D remains open. 


---
### Make Titles Informative.

If you want to teach programming language, it is necessary to present codes in your slide.

```python
import pandas as pd
```

---
 
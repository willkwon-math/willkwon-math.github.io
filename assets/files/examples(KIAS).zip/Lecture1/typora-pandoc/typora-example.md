

# Introduction 

In this presentation, we study the Dirichlet and Neumann problems  for second-order linear elliptic equations with singular drifts on a  bounded Lipschitz domain $\Omega$ in $\mathbb{R}^n$ $(n\geq 3)$.  Given a   vector-valued function $\boldb=\left(b^{1},\dots,b^{n}\right):\Omega\rightarrow\mathbb{R}^{n}$, we consider the following Dirichlet problems: 

$$\left\{\begin{alignedat}{2}
-\triangle u+\Div\left(u\boldb\right) & =f & \quad & \text{in }\Omega,\\
u & =u_{\Di} & \quad & \text{on }\partial\Omega \nonumber \end{alignedat}\right.$$

and

$$\left\{\begin{alignedat}{2}
-\triangle v-\boldb\cdot\nabla v & =g & \quad & \text{in }\Omega,\\
v & =v_{\Di} & \quad & \text{on }\partial\Omega.\end{alignedat}\right.$$

# Previous results and new results

Under the assumption $\boldb \in L^n(\Omega)^n$, 

- Droniou (2002) - $L^{2}_1$ -results when $\Omega$ is Lipschitz domain.
- Kim-Kim (2015) - $L_{1}^p$-results when $\Omega$ is $C^1$.
- Kim-K. (2018, preprint) - $L_{\alpha}^p$-results when $\Omega$ is Lipschitz domain.

Here $L_{\alpha}^p(\Omega)$ denotes the Sobolev spaces (or Bessel potential spaces)



# Coffee and Cold Noodle

![](cold-noodle.jpg)

![](espresso.jpg)